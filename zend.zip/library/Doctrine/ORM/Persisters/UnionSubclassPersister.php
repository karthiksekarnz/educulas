<?php

namespace Doctrine\ORM\Persisters;

class UnionSubclassPersister extends BasicEntityPersister
{
    
}