<?php

class App_Roles
{
	const GUEST = 'guest';
	const FREE ='free';
	const PAID = 'paid';
	const SCHOOL = 'school';
	const STAFF = 'staff';
	const STUDENT = 'student';
	const ADMIN = 'admin';

}