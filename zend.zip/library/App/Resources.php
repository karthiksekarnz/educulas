<?php

class App_Resources
{
	const PUBLIC_AREA = 'public';
	const FREE_AREA = 'free';
	const PAID_SECTION = 'paid';
	const ADMIN_SECTION = 'admin';
}
