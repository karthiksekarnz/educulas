<?php

class App_View_Helper_Notice extends Zend_View_Helper_Abstract
{
	public function notice()
	{
		echo "<div style=''>Hello world</div>";
	}
}