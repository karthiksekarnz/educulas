<?php

class ClassesController extends Zend_Controller_Action
{

    public function init()
    {
        /* Initialize action controller here */
    }

    public function indexAction()
    {
        $classform = new Application_Form_Classes();
        $this->view->autocompleteElement = $classform;

        if($this->_request->isPost())
        {
            $classdetails = $this->_getAllParams();
            var_dump($classdetails);
        }
       
    }

    public function createAction()
    {
        
    }


}

