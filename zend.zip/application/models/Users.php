<?php

class Application_Model_Users
{


}

