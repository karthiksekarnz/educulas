({
	invalidMessage: "Den angivne værdi er ikke gyldig.",
	missingMessage: "Værdien er påkrævet.",
	rangeMessage: "Værdien er uden for intervallet."
})
