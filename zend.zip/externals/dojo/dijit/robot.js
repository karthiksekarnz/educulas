dojo.provide("dijit.robot");
dojo.require("dojo.robot");
